import sqlite3
con=sqlite3.connect("mybooks.db")
cur=con.cursor()
cur.execute("create table booksl(id INTEGER PRIMARY KEY AUTOINCREMENT,image TEXT,bname TEXT,bprice,description TEXT,date TEXT)")
con.commit()
con.close()
