from flask import *

from datetime import date
import sqlite3
import os

app=Flask(__name__)
app.secret_key="blogtask"


UPLOAD_FOLDER="F:/books flask/static/img//"
app.config["UPLOAD_FOLDER"]=UPLOAD_FOLDER


# # Sample data for books (you might use a database in a real project)
# books = [
#     {'id': 1, 'title': 'Book 1', 'author': 'Author 1'},
#     {'id': 2, 'title': 'Book 2', 'author': 'Author 2'},
#     # Add more books as needed
# ]

# @app.route('/')
# def home():
#     return render_template('register.html')

@app.route("/")
def home():
   
    con=sqlite3.connect("mybooks.db")
    cur=con.cursor()
    cur.execute("select * from booksl ")
    result=cur.fetchall()
    return render_template("books.html",result=result)


@app.route('/view')
def view():
   
    con=sqlite3.connect("mybooks.db")
    cur=con.cursor()
    cur.execute("select * from booksl ")
    result=cur.fetchall()
    return render_template("view_more.html",result=result)
   


@app.route('/registration', methods=['GET', 'POST'])
def registration():
    if request.method == 'POST':
        fname = request.form["fname"]
        lname = request.form["lname"]
        email = request.form['email']
        password = request.form['password']
        
        # print(auth)
        
        
        
        con=sqlite3.connect("mydb.db")
        cur=con.cursor()
        cur.execute("insert into master(fname,lname,email,password)values(?,?,?,?)",(fname,lname,email,password))
        con.commit()
        
        return redirect(url_for("login"))

    else:
       return render_template('register.html')


@app.route("/login")
def login():
    return render_template("admin_login.html")


@app.route("/admin_login",methods=['POST','GET'])
def admin_login():
    if request.method=='POST':
        email=request.form['email']
        password=request.form['password']
        # auth = request.form['auth']
        
        if email=="admin@gmail.com" and password=="admin":
            session["username"]=email
            return redirect(url_for("admin_dashboard"))
        else:
            return redirect(url_for("member"))
        

#member
@app.route("/")
def member():
    return render_template("books.html")
        



   

# admin start

        
@app.route("/admin_dashboard")
def admin_dashboard():
    if session.get('username')is not None:
        return render_template("admin_dashboard.html")
    else:
        return redirect(url_for("login"))
    
@app.route("/logout")
def admin_logout():
    session.pop('username',None)
    return redirect(url_for("login"))

@app.route("/post_blog")
def post_blog():
    if session.get("username")is not None:
        return render_template("post_blog.html")
    else:
        return redirect(url_for("login"))
            
@app.route('/save_blog',methods=['POST','GET'])
def save_blog():
    if request.method =='POST':
       
        bname=request.form['bname']
        prc=request.form['bprice']
        description= request.form['description']
        f=request.files['image']
        todaysdate=date.today()
        #temp=os.path.abspath(f.name)
        
        
        f.save(os.path.join(app.config["UPLOAD_FOLDER"],f.filename))
        
        con=sqlite3.connect("mybooks.db")
        cur=con.cursor()
        cur.execute("insert into booksl(bname,bprice,description,image,date)values(?,?,?,?,?)",(bname,prc,description,f.filename,todaysdate))
        
        con.commit()
        con.close()
        return redirect(url_for("view_blog"))
    else:
        return redirect(url_for("post_blog"))
    
 
@app.route("/view_blog")
def view_blog():
    if session.get('username')is not None:
        con=sqlite3.connect("mybooks.db")
        cur=con.cursor()
        cur.execute("select * from booksl")
        result=cur.fetchall()
        return render_template("view_blog.html",rows=result)
    else:
        return redirect (url_for("login"))
    

@app.route("/blog_delete/<int:id>")
def blog_delete(id):
        con=sqlite3.connect("mybooks.db")
        cur=con.cursor()
        cur.execute("delete from booksl where id=?",[id])
        con.commit()
        # con.close()
        return redirect(url_for("view_blog"))
    
    
    
# from flask import render_template

@app.route("/blog_edit/<int:id>", methods=["GET", "POST"])
def blog_edit(id):
    con=sqlite3.connect("mybooks.db")
    cur = con.cursor()
    cur.execute("select * from booksl where id=?",[id])
    data = cur.fetchone()
    return render_template("blog_edit.html", data=data)



#profile updat

@app.route("/profile_update",methods=["POST","GET"])
def profile_update():
    if request.method =='POST':
        btitle=request.form['btitle']
        pname=request.form['pname']
        description= request.form['description']
        image=request.files['image']
        todaysdate=date.today()
        #temp=os.path.abspath(f.name)
        
        

        con = sqlite3.connect("mydb.db")
        cur = con.cursor()
        cur.execute("update booksl set btitle=?, pname=?, description=?, image=? where id=?",(btitle,pname,description,image,id))
        con.commit()

        return redirect(url_for("view_more"))
    else:
        return redirect(url_for("view_blog"))

# admin end



@app.route("/view_more/<int:id>")
def view_more(id):
        con=sqlite3.connect("mybooks.db")
        cur=con.cursor()
        cur.execute("select * from booksl  where id=?",[id])
        # con.commit()
        data = cur.fetchone()
        return render_template("view_more.html", data=data)

        # con.close()
        # return redirect(url_for("view_more"))
    




if __name__ == '__main__':
    app.run(debug=True)
