import sqlite3

con = sqlite3.connect("mydb.db")

cur = con.cursor()

cur.execute("create table master(id INTEGER PRIMARY KEY AUTOINCREMENT, fname TEXT, lname TEXT,email TEXT,password TEXT,auth TEXT)")

# cur.execute("alter table master add auth TEXT")
# cur.execute("alter table student add password TEXT")
# cur.execute("alter table student add photo TEXT")

con.commit()

con.close()